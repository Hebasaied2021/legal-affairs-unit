function bytesToHex(bytes){ return [...bytes].map(b=>b.toString(16).padStart(2,'0')).join(''); }
function hexToBytes(hex){
  const arr = new Uint8Array(hex.length/2);
  for(let i=0;i<arr.length;i++) arr[i] = parseInt(hex.substr(i*2,2),16);
  return arr;
}
function timingSafeEqualHex(a,b){
  if(a.length !== b.length) return false;
  let result = 0;
  for(let i=0;i<a.length;i++) result |= a.charCodeAt(i) ^ b.charCodeAt(i);
  return result === 0;
}

export async function hashPassword(password, saltHex){
  const enc = new TextEncoder();
  const salt = saltHex ? hexToBytes(saltHex) : crypto.getRandomValues(new Uint8Array(16));
  const keyMaterial = await crypto.subtle.importKey('raw', enc.encode(password), {name:'PBKDF2'}, false, ['deriveBits']);
  const bits = await crypto.subtle.deriveBits({name:'PBKDF2', salt, iterations:100000, hash:'SHA-256'}, keyMaterial, 256);
  return { hash: bytesToHex(new Uint8Array(bits)), salt: bytesToHex(salt) };
}
export async function verifyPassword(password, saltHex, hashHex){
  const { hash } = await hashPassword(password, saltHex);
  return timingSafeEqualHex(hash, hashHex);
}
export function newToken(){ return bytesToHex(crypto.getRandomValues(new Uint8Array(32))); }

export function parseCookies(request){
  const header = request.headers.get('Cookie') || '';
  const cookies = {};
  header.split(';').forEach(pair=>{
    const idx = pair.indexOf('=');
    if(idx>-1){
      cookies[pair.slice(0,idx).trim()] = decodeURIComponent(pair.slice(idx+1).trim());
    }
  });
  return cookies;
}

export async function getSessionUser(request, env){
  const cookies = parseCookies(request);
  const token = cookies['session'];
  if(!token) return null;
  const row = await env.DB.prepare(
    `SELECT s.token, s.expiresAt, u.id, u.username, u.fullName, u.role, u.department, u.active
     FROM sessions s JOIN users u ON u.id = s.userId
     WHERE s.token = ?`
  ).bind(token).first();
  if(!row) return null;
  if(new Date(row.expiresAt) < new Date()) return null;
  if(!row.active) return null;
  return row;
}

export function canAccessDepartment(user, department){
  if(user.role === 'admin') return true;
  if(!user.department) return true;
  return user.department === department;
}
