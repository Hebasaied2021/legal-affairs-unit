export async function onRequestGet({ env }) {
  const { results } = await env.DB.prepare(
    "SELECT name FROM departments ORDER BY name"
  ).all();
  return Response.json(results.map(r => r.name));
}

export async function onRequestPost({ request, env }) {
  const { name } = await request.json();
  if (!name || !name.trim()) {
    return Response.json({ error: 'name required' }, { status: 400 });
  }
  await env.DB.prepare(
    "INSERT OR IGNORE INTO departments (name) VALUES (?)"
  ).bind(name.trim()).run();
  return Response.json({ name: name.trim() });
}
