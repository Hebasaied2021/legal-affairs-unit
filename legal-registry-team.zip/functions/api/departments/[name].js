export async function onRequestDelete({ env, params }) {
  const name = decodeURIComponent(params.name);
  await env.DB.prepare("DELETE FROM departments WHERE name=?").bind(name).run();
  return Response.json({ deleted: true, name });
}
