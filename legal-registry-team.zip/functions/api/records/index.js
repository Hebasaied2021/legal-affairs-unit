function rowToRecord(r){
  return { ...r, attachments: r.attachments ? JSON.parse(r.attachments) : [] };
}

export async function onRequestGet({ env, data }) {
  const user = data.user;
  let sql = "SELECT * FROM records";
  const binds = [];
  if(user.department && user.role !== 'admin'){
    sql += " WHERE department = ?";
    binds.push(user.department);
  }
  sql += " ORDER BY registeredAt DESC";
  const stmt = env.DB.prepare(sql);
  const { results } = binds.length ? await stmt.bind(...binds).all() : await stmt.all();
  return Response.json(results.map(rowToRecord));
}

export async function onRequestPost({ request, env, data }) {
  const user = data.user;
  const body = await request.json();
  const id = body.id || crypto.randomUUID();
  const restricted = user.department && user.role !== 'admin';
  const department = restricted ? user.department : (body.department || '');
  const registeredBy = user.fullName || user.username;

  await env.DB.prepare(
    `INSERT INTO records
      (id, documentType, department, subject, relatedParty, issuingAuthority, legalBasis,
       documentDate, dueDate, reminderDays, action, notes, registeredBy, registeredAt, attachments)
     VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)`
  ).bind(
    id,
    body.documentType || '',
    department,
    body.subject || '',
    body.relatedParty || '',
    body.issuingAuthority || '',
    body.legalBasis || '',
    body.documentDate || '',
    body.dueDate || null,
    body.reminderDays || 30,
    body.action || 'review',
    body.notes || '',
    registeredBy,
    new Date().toISOString(),
    JSON.stringify(body.attachments || [])
  ).run();

  return Response.json({ ...body, id, department, registeredBy });
}
