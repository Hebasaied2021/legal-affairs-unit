import { canAccessDepartment } from '../../_lib/auth.js';

export async function onRequestPut({ request, env, params, data }) {
  const user = data.user;
  const existing = await env.DB.prepare("SELECT department FROM records WHERE id=?").bind(params.id).first();
  if(!existing) return Response.json({ error:'not found' }, { status:404 });
  if(!canAccessDepartment(user, existing.department)){
    return Response.json({ error:'forbidden' }, { status:403 });
  }

  const body = await request.json();
  const restricted = user.department && user.role !== 'admin';
  const department = restricted ? user.department : (body.department || existing.department);

  await env.DB.prepare(
    `UPDATE records SET
      documentType=?, department=?, subject=?, relatedParty=?, issuingAuthority=?, legalBasis=?,
      documentDate=?, dueDate=?, reminderDays=?, action=?, notes=?, attachments=?
     WHERE id=?`
  ).bind(
    body.documentType || '',
    department,
    body.subject || '',
    body.relatedParty || '',
    body.issuingAuthority || '',
    body.legalBasis || '',
    body.documentDate || '',
    body.dueDate || null,
    body.reminderDays || 30,
    body.action || 'review',
    body.notes || '',
    JSON.stringify(body.attachments || []),
    params.id
  ).run();

  return Response.json({ ...body, id: params.id, department });
}

export async function onRequestDelete({ env, params, data }) {
  const user = data.user;
  const existing = await env.DB.prepare("SELECT department FROM records WHERE id=?").bind(params.id).first();
  if(!existing) return Response.json({ error:'not found' }, { status:404 });
  if(!canAccessDepartment(user, existing.department)){
    return Response.json({ error:'forbidden' }, { status:403 });
  }
  await env.DB.prepare("DELETE FROM records WHERE id=?").bind(params.id).run();
  return Response.json({ deleted:true, id: params.id });
}
