import { getSessionUser } from '../_lib/auth.js';

export async function onRequest(context){
  const { request, env, next } = context;
  const url = new URL(request.url);

  if(url.pathname.startsWith('/api/auth/')){
    return next();
  }

  const user = await getSessionUser(request, env);
  if(!user){
    return Response.json({ error:'unauthorized' }, { status:401 });
  }
  context.data.user = user;

  const isWrite = ['POST','PUT','DELETE'].includes(request.method);
  if(isWrite && user.role === 'viewer'){
    return Response.json({ error:'forbidden' }, { status:403 });
  }
  if(url.pathname.startsWith('/api/users') && user.role !== 'admin'){
    return Response.json({ error:'forbidden' }, { status:403 });
  }

  return next();
}
