import { verifyPassword, newToken } from '../../_lib/auth.js';

export async function onRequestPost({ request, env }) {
  const { username, password } = await request.json();
  if(!username || !password){
    return Response.json({ error:'missing credentials' }, { status:400 });
  }
  const user = await env.DB.prepare("SELECT * FROM users WHERE username = ?").bind(username.trim()).first();
  if(!user || !user.active){
    return Response.json({ error:'invalid credentials' }, { status:401 });
  }
  const ok = await verifyPassword(password, user.salt, user.passwordHash);
  if(!ok){
    return Response.json({ error:'invalid credentials' }, { status:401 });
  }

  const token = newToken();
  const expiresAt = new Date(Date.now() + 7*24*60*60*1000).toISOString();
  await env.DB.prepare("INSERT INTO sessions (token, userId, expiresAt) VALUES (?,?,?)")
    .bind(token, user.id, expiresAt).run();

  const headers = new Headers({ 'Content-Type':'application/json' });
  headers.append('Set-Cookie', `session=${token}; Path=/; HttpOnly; Secure; SameSite=Lax; Max-Age=${7*24*60*60}`);
  return new Response(JSON.stringify({
    id:user.id, username:user.username, fullName:user.fullName, role:user.role, department:user.department
  }), { headers });
}
