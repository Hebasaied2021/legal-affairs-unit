import { getSessionUser, verifyPassword, hashPassword } from '../../_lib/auth.js';

export async function onRequestPost({ request, env }) {
  const user = await getSessionUser(request, env);
  if(!user) return Response.json({ error:'unauthorized' }, { status:401 });

  const { oldPassword, newPassword } = await request.json();
  if(!oldPassword || !newPassword || newPassword.length < 6){
    return Response.json({ error:'invalid input' }, { status:400 });
  }
  const row = await env.DB.prepare("SELECT * FROM users WHERE id = ?").bind(user.id).first();
  const ok = await verifyPassword(oldPassword, row.salt, row.passwordHash);
  if(!ok) return Response.json({ error:'current password is incorrect' }, { status:401 });

  const { hash, salt } = await hashPassword(newPassword);
  await env.DB.prepare("UPDATE users SET passwordHash=?, salt=? WHERE id=?").bind(hash, salt, user.id).run();
  return Response.json({ ok:true });
}
