import { parseCookies } from '../../_lib/auth.js';

export async function onRequestPost({ request, env }) {
  const cookies = parseCookies(request);
  const token = cookies['session'];
  if(token){
    await env.DB.prepare("DELETE FROM sessions WHERE token = ?").bind(token).run();
  }
  const headers = new Headers({ 'Content-Type':'application/json' });
  headers.append('Set-Cookie', `session=; Path=/; HttpOnly; Secure; SameSite=Lax; Max-Age=0`);
  return new Response(JSON.stringify({ ok:true }), { headers });
}
