import { getSessionUser } from '../../_lib/auth.js';

export async function onRequestGet({ request, env }) {
  const user = await getSessionUser(request, env);
  if(!user) return Response.json({ user:null });
  return Response.json({ user:{
    id:user.id, username:user.username, fullName:user.fullName, role:user.role, department:user.department
  }});
}
