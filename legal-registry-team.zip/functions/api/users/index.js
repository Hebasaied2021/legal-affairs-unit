import { hashPassword } from '../../_lib/auth.js';

export async function onRequestGet({ env }) {
  const { results } = await env.DB.prepare(
    "SELECT id, username, fullName, role, department, active, createdAt FROM users ORDER BY createdAt"
  ).all();
  return Response.json(results);
}

export async function onRequestPost({ request, env }) {
  const data = await request.json();
  if(!data.username || !data.password){
    return Response.json({ error:'username and password are required' }, { status:400 });
  }
  if(data.password.length < 6){
    return Response.json({ error:'password too short' }, { status:400 });
  }
  const id = crypto.randomUUID();
  const { hash, salt } = await hashPassword(data.password);
  try{
    await env.DB.prepare(
      `INSERT INTO users (id, username, passwordHash, salt, fullName, role, department, active, createdAt)
       VALUES (?,?,?,?,?,?,?,?,?)`
    ).bind(
      id, data.username.trim(), hash, salt,
      data.fullName || '', data.role || 'viewer', data.department || '', 1,
      new Date().toISOString()
    ).run();
  }catch(e){
    return Response.json({ error:'username already exists' }, { status:409 });
  }
  return Response.json({ id, username:data.username.trim(), fullName:data.fullName||'', role:data.role||'viewer', department:data.department||'', active:true });
}
