import { hashPassword } from '../../_lib/auth.js';

export async function onRequestPut({ request, env, params }) {
  const data = await request.json();
  if(data.password){
    if(data.password.length < 6){
      return Response.json({ error:'password too short' }, { status:400 });
    }
    const { hash, salt } = await hashPassword(data.password);
    await env.DB.prepare(
      "UPDATE users SET fullName=?, role=?, department=?, active=?, passwordHash=?, salt=? WHERE id=?"
    ).bind(data.fullName||'', data.role||'viewer', data.department||'', data.active?1:0, hash, salt, params.id).run();
  } else {
    await env.DB.prepare(
      "UPDATE users SET fullName=?, role=?, department=?, active=? WHERE id=?"
    ).bind(data.fullName||'', data.role||'viewer', data.department||'', data.active?1:0, params.id).run();
  }
  return Response.json({ id: params.id, username:data.username, fullName:data.fullName, role:data.role, department:data.department, active:!!data.active });
}

export async function onRequestDelete({ env, params }) {
  await env.DB.prepare("DELETE FROM users WHERE id=?").bind(params.id).run();
  await env.DB.prepare("DELETE FROM sessions WHERE userId=?").bind(params.id).run();
  return Response.json({ deleted:true, id: params.id });
}
